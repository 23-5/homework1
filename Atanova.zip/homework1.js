//1
let name = 'Ufa';
console.log(name);
let name2 = 'Russia';
console.log(name2); 
let number=1075000;
console.log(number);
let yes = true;
let no = false;
console.log(yes);
//2
let height = 40;
let width = 70
console.log(height*width);
//3
let time = 2;
let speedOfFirst = 95;
let speedOfSecond = 114;
let length = (`speedOfFirst*time + speedOfSecond*time`);
console.log(speedOfFirst*time + speedOfSecond*time);
//4
const randomNumber = Math.floor(Math.random() * 100);
if (randomNumber <20){
console.log('randomNumber меньше 20');
}
if (randomNumber >50){
console.log('randomNumber больше 50');
};
//5
const randomNumber2 = 'Math.floor(Math.random() * 100)';
switch (randomNumber2){
    case'randomNumber2 <20':
      console.log('randomNumber2 меньше 20');
      break;
    case'randomNumber2 >50':
      cosole.log('randomNumber2 больше 50');
      break;
    default:
        console.log('хз')  

}



